//
//  LMLKVideoFrame.h
//  Lumi
//
//  Created by PandaLZMing on 2018/7/5.
//

#import <Foundation/Foundation.h>

@class LMLKVideoFrameHeader;

@interface LMLKVideoFrame : NSObject
/// 视频桢类型
@property (nonatomic, assign) NSInteger frameType;
@property (nonatomic, strong) LMLKVideoFrameHeader *videoHeader;
@property (nonatomic)NSTimeInterval timeInterval;
@property (nonatomic, strong) NSData *frameInfo;
@property (nonatomic, strong) NSData *videoBuffer;
@property (nonatomic, assign) BOOL isLive;
@property (nonatomic, assign) BOOL isIFrame;
@property (nonatomic, assign) int videoWidth;
@property (nonatomic, assign) int videoHeight;
@property (nonatomic, assign) int fps;
@property(nonatomic)int length;
@property(nonatomic)uint8_t *buffer;
/** 包序号 */
@property (nonatomic, assign) UInt16 frameNo;
/** 视频时间戳 毫秒 */
@property(nonatomic, assign)long long videoTimeStamp;

@end
