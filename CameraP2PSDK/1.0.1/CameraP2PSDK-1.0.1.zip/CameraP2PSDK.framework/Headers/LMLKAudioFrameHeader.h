//
//  LMLKAudioFrameHeader.h
//  SCCameraFramework
//
//  Created by chenshuang on 2020/1/3.
//  Copyright © 2020   smart_camera. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LMLKAudioFrameHeader : NSObject

/** codec id */
@property(nonatomic, assign)int codecId;

// 编码格式：h264，h265
@property (nonatomic, copy) NSString *codec;

/// 采样位数
@property (nonatomic, assign) NSInteger databit;

/// 通道数
@property (nonatomic, copy) NSString *channels;

/// 采样率
@property (nonatomic, assign) NSInteger samplerate;

/// 每帧采集的大小
@property (nonatomic, assign) NSInteger sampleperframe;

/// 帧类型
@property (nonatomic, copy) NSString *frameType;

/// I帧序号
@property (nonatomic, assign) NSInteger iFrameIndex;

/// 包序号
@property (nonatomic, assign) UInt16 frameNo;

/// 帧率
@property (nonatomic, assign) int fps;

/// 宽度
@property (nonatomic, assign) int width;

/// 高度
@property (nonatomic, assign) int height;

/// 时间戳
@property (nonatomic, assign) NSInteger timestamp;

/// 签名校验
@property (nonatomic, copy) NSString *nonce;

/// 消息体长度
@property (nonatomic, assign) NSInteger length;

/** dec data */
@property(nonatomic, strong)NSData *decData;

/** header data */
@property(nonatomic, strong)NSData *headerData;

/** 音频时间戳 毫秒 */
@property(nonatomic, assign)long long audioTimeStamp;

/// Data转模型
- (instancetype)initWithData:(NSData *)data;

/// 获取音频类型
- (int)getAudioCodec;

/// 获取音频通道
- (int)getAudioChannels;

@end

NS_ASSUME_NONNULL_END
