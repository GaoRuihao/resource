//
//  LMLKVideoFrameHeader.h
//  SCCameraFramework
//
//  Created by chenshuang on 2020/1/3.
//  Copyright © 2020   smart_camera. All rights reserved.
//

#import <Foundation/Foundation.h>

FOUNDATION_EXTERN NSString *const kLMLKP2PCodecTypeH264Key;
FOUNDATION_EXTERN NSString *const kLMLKP2PCodecTypeH265Key;

FOUNDATION_EXTERN NSString *const kLMLKP2PFrameTypeIKey;
FOUNDATION_EXTERN NSString *const kLMLKP2PFrameTypeIDRKey;
FOUNDATION_EXTERN NSString *const kLMLKP2PFrameTypePKey;

NS_ASSUME_NONNULL_BEGIN

@interface LMLKVideoFrameHeader : NSObject
/** codec id */
@property(nonatomic, assign)int codecId;

/// 编码格式：h264，h265
@property (nonatomic, copy) NSString *codec;

/// 帧类型
@property (nonatomic, copy) NSString *frameType;

/// I帧序号
@property (nonatomic, assign) NSInteger iFrameIndex;

/// 包序号
@property (nonatomic, assign) UInt16 frameNo;

/// 帧率
@property (nonatomic, assign) int fps;

/// 宽度
@property (nonatomic, assign) int width;

/// 高度
@property (nonatomic, assign) int height;

/// 时间戳
@property (nonatomic, assign) NSInteger timestamp;

/// 消息体长度
@property (nonatomic, assign) NSInteger length;

/** dec data */
@property(nonatomic, strong)NSData *decData;

/** header data */
@property(nonatomic, strong)NSData *headerData;

/// 签名校验
@property (nonatomic, copy) NSString *nonce;

/// nalu
@property (nonatomic, strong) NSArray *nalu;

/** 视频时间戳 毫秒 */
@property(nonatomic, assign)long long videoTimeStamp;

/// Data转模型
- (instancetype)initWithData:(NSData *)data;

/// 门锁Data转模型
- (instancetype)initWithLockData:(NSData *)data;

@end

NS_ASSUME_NONNULL_END
