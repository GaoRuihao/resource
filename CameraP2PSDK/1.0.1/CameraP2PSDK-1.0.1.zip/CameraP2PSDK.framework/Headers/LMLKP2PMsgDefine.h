//
//  LMLKP2PMsgDefine.h
//  CameraP2PSDK
//
//  Created by chenshuang on 2021/11/11.
//

#ifndef LMLKP2PMsgDefine_h
#define LMLKP2PMsgDefine_h

#define LMLKP2PDecryptFail      0x2000
#define LMLKP2PSleep            0x2001
#define LMLKP2PUnknowError      0x2002
#define LMLKP2PDeviceOffline    0x2003
#define LMLKP2PAuthFail         0x2004
#define LMLKP2PInitFail         0x2005
#define LMLKP2PSessionClosed    0x2006
#define LMLKP2PAACDecryptFail   0x3000
#define LMLKP2PTimeOut          0x3001
#define LMLKP2PSessionBeyondLimit 0x3002

#endif /* LMLKP2PMsgDefine_h */
