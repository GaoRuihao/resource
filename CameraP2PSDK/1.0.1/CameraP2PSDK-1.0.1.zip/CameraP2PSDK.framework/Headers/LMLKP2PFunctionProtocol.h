//
//  LMLKP2PFunctionProtocol.h
//  LMLKmeraFramework
//
//  Created by chenshuang on 2021/11/7.
//  Copyright © 2021 chenshuang. All rights reserved.
//

#import "LMLKP2PHeader.h"

@class LMLKP2PConnectParam;
@class LMLKVideoFrame;
@class LMLKAudioFrame;

#ifndef LMLKP2PFunctionProtocol_h
#define LMLKP2PFunctionProtocol_h

/**
 命令回调，非主线程！！！

 @param isSuccess 结果是否成功
 @param error 如果错误，会带有error信息
 */
typedef void(^LMLKP2PResultBlock)(BOOL isSuccess,  NSError * _Nullable error);

/// p2p底层建立连接，发送数据，解析类型
typedef NS_ENUM(NSInteger, LMLKP2PConnectType) {
    LMLKP2PConnectType_Camera = 0,  // G2,G2H,G3...协议
    LMLKP2PConnectType_Doorlock,    // 门锁协议
    LMLKP2PConnectType_WebRTC       // WebRTC协议
};

/// p2p建立连接进度
typedef NS_ENUM(NSInteger, LMLKP2PConnectingProgressStatus) {
    LMLKP2PConnectingProgressStatus_StartConnect = 0,       // 开始连接
    LMLKP2PConnectingProgressStatus_AuthCompletion = 1,     // 鉴权完成
};

/// 与P2P底层建立连接，发送命令，接收数据的中间层
@protocol LMLKP2PFunctionDataSource <NSObject>

@optional
/// 建立连接进度
/// @param connectingStatus 连接进度
- (void)p2pBuildConnectingStatus:(LMLKP2PConnectingProgressStatus)connectingStatus;

/// P2P连接状态回调
/// @param status 连接状态
- (void)p2pConnectStatus:(LMLK_P2PCamManagerConnectStatus)status;

/// P2P连接模式，直连或者是转发
- (void)p2pConnectMode:(NSInteger)p2pMode;

/// 发生错误的回调
/// @param error 错误信息
- (void)p2pFailureResult:(NSError * _Nonnull)error;

/// 接受到视频帧回调数据
/// @param frame 视频帧
- (void)p2pVideoFrameReceived:(LMLKVideoFrame * _Nonnull)frame;

/// 接受到音频帧回调数据
/// @param frame 音频帧
- (void)p2pAudioFrameReceived:(LMLKAudioFrame * _Nonnull)frame;

/// 鉴权成功
- (void)p2pAuthSuccess;

/// 回放结束，自动切换到实时
/// @param error 错误信息
- (void)p2pPlaybackEndTurnToLiveWithCompletion:(NSError *)error;

/// 获取历史回放数据
/// @param data 历史回放数据
/// @param needStop 是否需要停止
/// @param error 发生错误信息
- (void)p2pRecordHistory:(NSData *)data needStop:(BOOL)needStop error:(NSError *)error;

/// 每秒收到数据的大小
/// @param size 大小，单位kb
- (void)p2pRecievedBitSizePerSecond:(NSInteger)size;

@end

/// 与P2P底层建立连接，发送命令，接收数据的中间层
@protocol LMLKP2PFunctionDelegate <NSObject>

@required
/// 更新连接参数
/// @param param 连接参数
- (void)updateConnectParam:(LMLKP2PConnectParam *)param;

/// 开始连接
- (void)connect;

/// 开始连接
- (void)connectUseTcpRelayMode:(BOOL)useTcpRelayMode;

/// 断开连接
/// @param completion 结果回调，不一定成功断开连接
- (void)disconnectWithCompltion:(nullable void(^)(BOOL isFinished))completion;

/// 开始发送心跳(鉴权成功之后调用)
- (void)startHeartbeat;

/// 切换至实时
/// @param completion 结果回调
- (void)playLiveWithCompltion:(nullable LMLKP2PResultBlock)completion;

/// 暂停实时播放
/// @param completion 结果回调
- (void)pauseLiveWithCompletion:(nullable LMLKP2PResultBlock)completion;

/// 播放音频
/// @param completion 结果回调
- (void)playAudioWithCompletion:(nullable LMLKP2PResultBlock)completion;

/// 暂停播放音频
/// @param completion 结果回调
- (void)pauseAudioWithCompletion:(nullable LMLKP2PResultBlock)completion;

/// 恢复实时播放
/// @param completion 结果回调
- (void)resumeLiveWithCompletion:(nullable LMLKP2PResultBlock)completion;

/// 切换回放播放
/// @param timeStr 回放时间戳
/// @param completion 结果回调
- (void)playBackWithTime:(NSString *_Nullable)timeStr pathName:(NSString *_Nullable)pathName fileName:(NSString *_Nullable)fileName completion:(nullable LMLKP2PResultBlock)completion;

/// 暂停回放播放
/// @param completion 结果回调
- (void)pausePlaybackWithCompletion:(nullable LMLKP2PResultBlock)completion;

/// 恢复回放播放
/// @param completion 结果回调
- (void)resumePlaybackWithCompletion:(nullable LMLKP2PResultBlock)completion;

/// 获取历史回放数据
/// @param completion 结果回调
/// 查询的结果通过代理方法回调
- (void)getRecordListWithCompletion:(nullable LMLKP2PResultBlock)completion;

/// 改变视频清晰度
/// @param stream 0:超清 1:高清 2:标清
/// @param isLive 是否是实时
/// @param completion 结果回调
- (void)changeStream:(LMLKCameraVideoStream)stream isLive:(BOOL)isLive completion:(nullable void(^)(BOOL isSuccess))completion;

/// 改变回放速度
/// @param speed 0:正常 1:2倍速 2:4倍速 3:16倍速
/// @param completion 结果回调
- (void)changeSpeed:(LMLKCameraPlaybackSpeed)speed completion:(nullable void(^)(BOOL isSuccess))completion;

/// 开始通话
/// @param completion 结果回调
- (void)startTalkWithCompletion:(nullable LMLKP2PResultBlock)completion;

/// 停止通话
/// @param completion 结果回调
- (void)stopTalkWithCompletion:(nullable LMLKP2PResultBlock)completion;

/** 发送语音数据 */
- (void)sendAudioData:(NSData *)audioData;

@end

#endif /* LMLKP2PFunctionProtocol_h */
