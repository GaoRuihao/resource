//
//  GHCameraOpenSDKConfig.h
//  SCCameraFramework
//
//  Created by 高瑞浩 on 2024/10/4.
//  Copyright © 2024 smart_camera. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SCCameraOpenSDKConfig : NSObject

+ (void)setServer:(NSString *)serverHost;

+ (void)setUserId:(NSString *)userId token:(NSString *)token;

+ (void)setLanguage:(NSString *)lan;

/// SDK version
+ (NSString * _Nonnull)getFrameworkVersion;

@end

NS_ASSUME_NONNULL_END
