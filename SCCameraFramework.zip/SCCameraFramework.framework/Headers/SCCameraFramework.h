//
//  SCCameraFramework.h
//  SCCameraFramework
//
//  Created by chenshuang on 2020/5/24.
//  Copyright © 2020 chenshuang. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for LMCameraFramework.
FOUNDATION_EXPORT double LMCameraFrameworkVersionNumber;

//! Project version string for LMCameraFramework.
FOUNDATION_EXPORT const unsigned char LMCameraFrameworkVersionString[];

#import <SCCameraFramework/SCCameraOpenSDKConfig.h>

#import <SCCameraFramework/SCCameraManager.h>
