//
//  SCCameraDefine.h
//  SCCameraFramework
//
//  Created by 高瑞浩 on 2025/2/16.
//  Copyright © 2025 smart_camera. All rights reserved.
//

#ifndef SCCameraDefine_h
#define SCCameraDefine_h

typedef NS_ENUM(NSInteger, SCConnectorMode) {
    SCConnectorModeP2P = 0,          // P2P - jame确认，默认显示p2p
    SCConnectorModeRelay,        // Relay
};

#endif /* SCCameraDefine_h */
