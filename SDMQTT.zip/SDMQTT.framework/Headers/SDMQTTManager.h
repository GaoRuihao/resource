//
//  Test.h
//  SDMQTT
//
//  Created by 高瑞浩 on 2024/11/9.
//

#import <Foundation/Foundation.h>

FOUNDATION_EXTERN NSString * _Nullable const kSCMQTTEventTopicKey;
FOUNDATION_EXTERN NSString * _Nullable const kSCMQTTAttrTopicKey;

typedef enum : NSUInteger {
    SDMQTTStateConnected,
    SDMQTTStateConnectionRefused,
    SDMQTTStateConnectionClosed,
    SDMQTTStateConnectionError,
    SDMQTTStateProtocolError,
    SDMQTTStateClosedByBroker,
} SDMQTTState;

@protocol SDMQTTManagerDelegate <NSObject>

- (void)handleEvent:(SDMQTTState)eventCode error:(NSError *_Nullable)error;

- (void)newMessageRecievedWithData:(NSData *)data onTopic:(NSString *)topic dataDic:(NSDictionary *)dataDic retained:(BOOL)retained mid:(unsigned int)mid;

@end


@interface SDMQTTManager : NSObject

@property(nonatomic, weak)id<SDMQTTManagerDelegate> delegate;

- (instancetype _Nullable )initWithDelegate:(id _Nullable)delegate;

- (void)setupMQTTCompletion:(void(^_Nullable)(NSError * _Nullable error))completion;

- (void)loginMQTT;

- (void)subscribeToTopicWithDid:(NSString *_Nullable)did completion:(void(^_Nullable)(NSError * _Nullable error))completion;

- (void)closeMQTTClientWithCompletion:(void(^_Nullable)(NSError * _Nullable error))completion;

/// 获取回放记录
- (void)getFileListWithDid:(NSString *_Nullable)did type:(NSInteger)type sort:(NSInteger)sort channel:(NSInteger)channel offset:(NSInteger)offset completion:(void(^_Nullable)(NSError * _Nullable error))completion;

/// 获取回放缩略图
- (void)getVideoThumbnailWithList:(NSArray *_Nullable)arry did:(NSString *_Nullable)did completion:(void(^_Nullable)(NSError * _Nullable error))completion;

@end

