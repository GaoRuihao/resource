//
//  LHConstant.h
//  commonDemo
//
//  Created by dengzhihao on 2017/11/20.
//  Copyright © 2017年 LM21Mac002. All rights reserved.
//
#import <Foundation/Foundation.h>

#ifndef LHConstant_h
#define LHConstant_h

//#import "LHModelConstant.h"

FOUNDATION_EXTERN NSString * const kLH_Aqara;
FOUNDATION_EXTERN NSString * const kLH_Mi;
FOUNDATION_EXTERN NSString * const kLH_EigenStone;
FOUNDATION_EXTERN NSString * const kLH_AppStoreUrl;

FOUNDATION_EXTERN NSString * const kLH_AssociatedServiceTypeDescription;
FOUNDATION_EXTERN NSString * const kLH_ButtonTriggerIdentifier;

FOUNDATION_EXTERN NSString * const kLH_FeedbakMailAddress;
FOUNDATION_EXTERN NSString * const kLH_AqaraUrl;

FOUNDATION_EXTERN NSString * const kLH_BaseUrl;

FOUNDATION_EXTERN NSString * const kLH_ContryListKey;

FOUNDATION_EXTERN NSString * const kLH_NewFirmwareKey;


FOUNDATION_EXTERN NSString * const kLH_UserLoginStatus;
FOUNDATION_EXTERN NSString * const kLH_LastUserID;
FOUNDATION_EXTERN NSString * const kLH_LastUserToken;

FOUNDATION_EXTERN NSString * const kLH_AppKey;
FOUNDATION_EXTERN NSString * const kLH_AppId;
FOUNDATION_EXTERN NSString * const kLH_Temperature;
FOUNDATION_EXTERN NSString * const kLH_Atmospheric;

FOUNDATION_EXTERN NSString * const kLH_NewAppKey;
FOUNDATION_EXTERN NSString * const kLH_NewAppId;

FOUNDATION_EXTERN NSString * const kLH_NeedChangeTabbarKey;

FOUNDATION_EXTERN NSString * const kLH_ServiceIMAccessKey;

FOUNDATION_EXTERN NSString * const kCameraFlowProtectKey;

FOUNDATION_EXTERN NSString * const kCameraShowGuideKey;

FOUNDATION_EXTERN NSString * const kCameraShowVideoInfoKey;

FOUNDATION_EXTERN NSString * const kCameraShowCalendarInfoKey;

FOUNDATION_EXTERN NSString * const kCameraSecretVerifyErrorKey;

FOUNDATION_EXTERN NSString * const kCameraLockResultKey;

FOUNDATION_EXTERN NSString * const kCameraVerifyTimeKey;

FOUNDATION_EXTERN NSString * const kLoginRegisterAccountKey;

FOUNDATION_EXTERN NSString * const kLoginRegisterTimeKey;

FOUNDATION_EXTERN NSString * const kLoginRegisterCountDownKey;

FOUNDATION_EXTERN NSString * const kLoginRegisterVerifyTypeKey;

FOUNDATION_EXTERN NSString *const kLHNotificationCancelServiceClause;
FOUNDATION_EXTERN NSString *const kLHNotificationAgreeServiceClause;
 
FOUNDATION_EXTERN NSString *const kLHCacheUserInfoKey;
FOUNDATION_EXTERN NSString *const kLHHomeKitLoginMode;
FOUNDATION_EXTERN NSString *const kHadPresentHomeKitStopUpdatingTipViewController;
FOUNDATION_EXTERN NSString *const kHadPresentEuServiceOnlineTipViewController;
FOUNDATION_EXTERN NSString *const kNeedPresentBindToHomeKitTipViewController;

//隐私政策
FOUNDATION_EXTERN NSString *const kUserPrivacyAgreement;
//使用条款
FOUNDATION_EXTERN NSString *const kTermsUse;

FOUNDATION_EXTERN NSString *const kLHMainpageOverviewWhiteListKey;

/// 萤石appkey
FOUNDATION_EXTERN NSString *const kLH_YSAppKey;

FOUNDATION_EXPORT NSString *const KEY_BLE_MAC;

#endif /* LHConstant_h */

//FOUNDATION_EXTERN NSString * const

//NSString *const

//const CGFloat
