//
//  LHTempModel.h
//  SCCameraFramework
//
//  Created bysmart_cameraon 2019/1/29.
//  Copyright © 2019   smart_camera. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LHTempModel : NSObject

@property(nonatomic, strong)NSString *temperatureValue;

///这里为了避免跟系统的floatValue方法冲突
@property(nonatomic)CGFloat oFloatValue;

@property(nonatomic, strong)NSString *unit;

@end
