//
//  UISegmentedControl+Common.h
//  SCCameraFramework
//
//  Created by 赵希帆 on 2020/4/14.
//  Copyright © 2020   smart_camera. All rights reserved.
//


#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UISegmentedControl (Common)

- (void)ensureiOS12Style;

@end

NS_ASSUME_NONNULL_END
