//
//  MHLumiSyncOperation.h
//  MiHome
//
//  Created by LM21Mac002 on 2017/1/3.
//  Copyright © 2017年 LM21Mac002. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MHLumiSyncOperationHeader.h"

@class MHLumiSyncOperationQueue;
@interface MHLumiSyncOperation : NSOperation
@property (nonatomic, assign, readonly) MHLumiSyncOperationResult resultStatus;
@property (nonatomic, weak) MHLumiSyncOperationQueue *nopQueue;
@property (nonatomic, assign, readonly) BOOL isSuccessful;
@property (nonatomic, copy) MHLumiSyncOperationCancelBlock cancelBlock;
- (instancetype)initWithStatusBlock:(MHLumiSyncOperationStatusBlock) statusBlock;
- (instancetype)initWithFlagBlock:(MHLumiSyncOperationFlagBlock) flagBlock;
- (void)success;
- (void)failure;
- (void)startWithAboveOperation:(MHLumiSyncOperation *)aboveOperation;
@end
