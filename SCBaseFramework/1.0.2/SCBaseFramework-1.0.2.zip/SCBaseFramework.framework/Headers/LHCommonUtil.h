//
//  LHCommonUtil.h
//  Aqara
//
//  Created by 赵希帆 on 2018/1/11.
//  Copyright © 2018年 LumiUnited. All rights reserved.
//

#import <UIKit/UIKit.h>

@class LHTempModel;
typedef void (^Task)(BOOL cancel);

@interface LHCommonUtil : NSObject

+ (BOOL)isValidateEmail:(NSString *)email;
+ (BOOL)isPhoneNum:(NSString *)str;

+ (BOOL)isALlNumber:(NSString *)str;
+ (NSString *)trimming:(NSString *)string;
+ (UIColor *)colorWithHexString:(NSString *)stringToConvert alpha:(float)alpha;

+ (NSString *)jsonStringFromObject:(id)object;

+ (id)objectFromJsonString:(NSString *)jsonString;
+ (BOOL)isJsonString:(NSString *)jsonString;

+ (Task)delay:(NSTimeInterval)time task:(void(^)(void))task;

+ (CGSize)labelSizeWithContent:(NSString *)content font:(UIFont *)font size:(CGSize)size;
+ (CGSize)labelSizeWithAttributContent:(NSAttributedString *)content size:(CGSize)size;

/**
 获取当前连接的WIFI名称

 @return 返回WIFI名称，没有连接WIFI就返回@""
 */
+ (NSString *)currentWiFiName;

+ (NSString *)appImagePrefix;

+ (id)objectFromNSData:(NSData *)data;

+ (NSString *)stringWithHexNumber:(NSInteger)hexNumber;
+ (NSInteger)numberWithHexString:(NSString *)hexString;
+(NSString *)ToHex:(long long int)tmpid;

+ (UIEdgeInsets)safeAreaInsetsEdge;

/**
 把云端的摄氏度转成本地的温度单位
 */
+ (LHTempModel *)getLocalTemperature:(CGFloat)celsiusValue;

+ (LHTempModel *)getLocalTVOCUnit:(CGFloat)ppbValue;

/// 转换云端大气压单位数据
+ (LHTempModel *)getLocalAtmosphericUnit:(CGFloat)kpaValue;

/// 转回到摄氏度
+ (CGFloat)getCelsiusValue:(CGFloat)temperatureValue;

/// 从ppb转换成mg/m³
/// @param ppbValue
+ (CGFloat)getVOCValue:(CGFloat)ppbValue;

+ (CGFloat)getPPBValue:(CGFloat)vocValue;

/// 获取当前空气质量等级
/// @param vocValue voc指数
+ (NSString *)getVOCLevel:(CGFloat)vocValue;

+ (NSString *)getFirstEnterKey;
//不同版本不同的首次启动标记
+ (NSString *)getVersionFirstEnterKey;

+ (BOOL)isNeedPresentLoginPage;

+ (BOOL)isNeedChangeTabbar;

/**
 根据URL创建二维码的CIImage
 */
+ (CIImage *)QRFromUrl:(NSString *)urlStr;

/// 根据url 创建CIImage - inputCorrectionLevel:设定容错率
+ (CIImage *)QRFromUrl:(NSString *)urlStr inputCorrectionLevel:(NSString *)inputCorrectionLevel;

+ (UIImage *)createUIImageFormCIImage:(CIImage *)image withSize:(CGFloat)size;

+ (BOOL)isInChinses;

+ (UIViewController *)getCurrentVC;

#pragma mark - 字符串判断

+ (BOOL)isPureFloat:(NSString *)string;

+ (BOOL)isPureInt:(NSString *)string;

#pragma mark - GBK
/// 把十六进制GBK编码转成文字
+ (NSString *)convertToGBKCharactersWithGBKStr:(NSString *)gbkStr;

/// 把文字转成十六进制GBK编码
+ (NSString *)convertToGBKCodeWithStr:(NSString *)str;

/// 将数组元素按规定元素个数划分N个子数组
+ (NSMutableArray<NSArray *> *)splitArrayWithEachArrayCount:(NSInteger)count withOrginArray:(NSArray *)orginAarray;

/// 根据当前视图View获取到当前视图VC
+ (UIViewController *)getViewControllerNextResponder:(id)superModel;

/// 获取url中的所有参数
+ (NSDictionary *)paramerWithURL:(NSURL *)url;

@end
