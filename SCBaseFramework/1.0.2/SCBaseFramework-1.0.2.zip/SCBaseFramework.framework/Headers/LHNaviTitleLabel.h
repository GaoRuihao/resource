//
//  LHNaviTitleLabel.h
//  SCCameraFramework
//
//  Created by MadHeart on 2018/7/5.
//  Copyright © 2018年   smart_camera. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LHNaviTitleLabel : UIView

@property(nonatomic, strong)NSString *title;
@property(nonatomic, assign) CGSize intrinsicContentSize;

@end
