//
//  LHDateTool.h
//  SCCameraFramework
//
//  Created by 赵希帆 on 2018/5/2.
//  Copyright © 2018年   smart_camera. All rights reserved.
//

#import <Foundation/Foundation.h>
#define LHDLTC_DATE_FORMAT_WSEC @"yyyy-MM-dd HH:mm:ss"
#define LHDLTC_DATE_FORMAT_NOSEC @"yyyy-MM-dd HH:mm"
#define LHDLTC_DATE_FORMAT_YMD @"yyyy/MM/dd"
#define LHDLTC_DATE_FORMAT_MDHM @"MM/dd HH:mm"
#define LHDLTC_DATE_FORMAT_MD @"MM/dd"
#define LHDLTC_DATE_FORMAT_HM @"HH:mm"
#define LHDLTC_DATE_FORMAT_BWSEC @"yyyy/MM/dd HH:mm:ss"
#define LHDLTC_DATE_FORMAT_BNOSEC @"yyyy/MM/dd HH:mm"
@interface LHDateTool : NSObject

// 把date转化成默认时区时间,本地时间为GMT
+ (NSDate *)getDefaultDateFromUTCDate:(NSDate *)date;

// 把date转化成系统时区时间,本地时间为GMT
+ (NSDate *)getSystemDateFromUTCDate:(NSDate *)date;

+ (NSDate *)getDestinationTimeFromUICDate:(NSDate *)date withTimeZone:(NSString *)timeZone;

+ (NSString *)getDateStringWithFormatter:(NSString *)formatter withDate:(NSDate *)date;

+ (NSString *)getHourAndMinuteNow;

+ (NSString *)currentTimeStr;

+ (void)saveShortcutsExtentsionKey:(NSString *)key value:(id)value;

+ (BOOL)compareSameDayWithDate1:(NSDate *)date1 date2:(NSDate *)date2;
/// dateType 0:day 1:week 2:month
+ (BOOL)compareType:(NSInteger)dateType withDate1:(NSDate *)date1 date2:(NSDate *)date2;

/** 获取星期的数组， 从周日到周六 */
+ (NSArray *)getWeekDayStrArray;

+ (NSArray *)getSimpleWeekDays;

+ (NSArray *)getWeeks:(NSArray *)nums;

/**
 星期数组转日期字符串，格式用空格隔开
 @param days days
 @return 日期字符串：周末， 周一到周五， 周一 周二等
 */
+ (NSString *)converWeekDayToStr:(NSArray *)days;

/**
 门锁：星期数组转日期字符串，格式用空格隔开
 @param days days
 @return 日期字符串：周末， 周一到周五， 周一 周二等
 */
+ (NSString *)lockConverWeekDayToStr:(NSArray *)days;

/**
 通用的时间格式解析器，返回时间格式为"今天 HH:mm" "昨天 HH:mm" "MM/dd HH:mm"
 @param needTodayStr 是否需要拼接”今天“字符串
 */
+ (NSString *)defaultDateStr:(NSDate *)date needTodayStr:(BOOL)needTodayStr;

/**
 比较两个时间得大小

 @param formate 格式
 @param selectDate 选中得时间
 @param currentDate 当前得时间
 @return 结果
 */
+ (int)compareFormat:(NSString *)formate Date:(NSString *)selectDate withDate:(NSString *)currentDate;

/**
 NSString转NSDate

 @param string 时间字符串
 @param format 时间格式
 @return NSDate
 */
+ (NSDate *)dateFromString:(NSString *)string format:(NSString *)format;

//NSDate转NSString
+ (NSString *)stringFromDate:(NSDate *)date format:(NSString *)format;

//根据format转换date
+ (NSString *)transformDate:(NSString *)date fromFormat:(NSString *)dateFormate toFormat:(NSString *)toFormat;

// 时间戳转时间
+ (NSString *)getTimeStringWithTimeInterval:(NSTimeInterval)timeInterval format:(NSString *)format;

//时间字符串转时间戳 如：2017/4/10 17:15
+ (NSTimeInterval)getTimeIntervalWithTimeString:(NSString *)timeString format:(NSString *)format;

//获取当前时间戳
+ (NSTimeInterval)currentTimeInterval;

// 输出格式   HH:mm ,  昨天 hh:mm ,  MM/dd hh:mm，   去年： YYYY-MM:dd hh:mm  比上面少了一个今天  和首页的Service显示一样
 //代码copy的首页
+ (NSString*)getTimeStringWithDate:(NSDate*)date dateFormat:(NSString*)dateFormat;

/// 输出格式 今天内：hh:mm 今天之前：mm/dd hh:mm 一年前：yyyy
/// @param Interval 时间戳
+ (NSString *)getTimeStringWithInterval:(NSInteger)Interval;

@end
