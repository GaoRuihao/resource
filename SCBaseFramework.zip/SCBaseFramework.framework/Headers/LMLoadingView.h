//
//  LMLoadingView.h
//  SCBaseFramework
//
//  Created by jeremy on 2021/7/26.
//  Copyright © 2021   smart_camera. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LMLoadingView : UIImageView

- (instancetype)initWithLoadingImage:(UIImage *)image;

- (void)lmStartLoading;

- (void)lmEndLoading;

@end

NS_ASSUME_NONNULL_END
