//
//  MHLumiSyncOperationHeader.h
//  MiHome
//
//  Created by LM21Mac002 on 2017/1/3.
//  Copyright © 2017年 LM21Mac002. All rights reserved.
//

#ifndef MHLumiSyncOperationHeader_h
#define MHLumiSyncOperationHeader_h
typedef NS_ENUM(NSInteger, MHLumiSyncOperationResult){
    MHLumiSyncOperationResultSuccess = 0 ,
    MHLumiSyncOperationResultFailure ,
    MHLumiSyncOperationResultCancel  ,
    MHLumiSyncOperationResultPrepared ,
};

@class MHLumiSyncOperation;
typedef void(^MHLumiSyncOperationStatusBlock)(MHLumiSyncOperation *operation,MHLumiSyncOperationResult lastResult);
typedef void(^MHLumiSyncOperationFlagBlock)(MHLumiSyncOperation *operation,BOOL flag);
typedef void(^MHLumiSyncOperationCancelBlock)(MHLumiSyncOperation *operation);
typedef void(^MHLumiSyncOperationBlock)(MHLumiSyncOperation *operation);
#endif /* MHLumiSyncOperationHeader_h */
