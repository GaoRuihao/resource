//
//  NSDate+Extension.h
//  SCCameraFramework
//
//  Created by 赵希帆 on 2018/5/2.
//  Copyright © 2018年   smart_camera. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSDate (Extension)

- (BOOL) isYesterday;
- (BOOL) isThisYear;
- (BOOL) isToday;
- (BOOL)isTomorrow;
- (BOOL)isAYearAgo;
//- (BOOL) isTodayWithTimeZone:(NSTimeZone *)timeZone;
- (NSString *)getFormmatDateString;
- (NSString *)getWeek;
- (NSString *)getWeekShort;
- (NSString *)getClock;


/**
 获取当前时间前几个月的时间戳

 @param index 几个月前
 @param isFirstDay 是否需要目标月的第一天
 @return 目标月的时间戳
 */
- (long long)getEarlierMonthTimeStampWithIndex:(NSInteger)index firstDay:(BOOL)isFirstDay;
/*
 根据GMT转化成网关时间
 */
+(NSString *)showDateYmdhmsWithGMT:(NSInteger)gmt;

/**
 获得当天0点的时间戳

 @param timeInterval 当前时间时间戳
 @return 当天0点的时间戳
 */
+ (long long)getToday0ClockTimeStamp:(NSTimeInterval)timeInterval;
//+ (long long)getToday0ClockTimeStamp:(NSTimeInterval)timeInterval withTimeZone:(NSTimeZone *)timeZone;

/**
 获得当周0点的时间戳

 @param timeInterval 当前时间时间戳
 @return 当周0点的时间戳
 */
+ (long long)getWeek0ClockTimeStamp:(NSTimeInterval)timeInterval;
//+ (long long)getWeek0ClockTimeStamp:(NSTimeInterval)timeInterval withTimeZone:(NSTimeZone *)timeZone;

/**
 获得当月第一天的时间戳

 @param timeInterval 当前时间时间戳
 @return 当月第一天的0点时间戳
 */
+ (long long)getCurrentMonthFirstDayTimeStamp:(NSTimeInterval)timeInterval;
/**
 获得次月第一天的时间戳

 @param timeInterval 当前时间时间戳
 @return 次月第一天的0点时间戳 （-1秒则为当月最后一天的23:59:59）
 */
+ (long long)getCurrentMonthLastDayTimeStamp:(NSTimeInterval)timeInterval;

/**
 获得当年第一天0点的时间戳

 @param timeInterval 当前时间时间戳
 @param timeZone 时区 （可以传空，传空时使用默认时区）
 @return 当年第一天0点的时间戳
 */
//+ (long long)getYear0ClockTimeStamp:(NSTimeInterval)timeInterval withTimeZone:(NSTimeZone *)timeZone;
+ (long long)getYear0ClockTimeStamp:(NSTimeInterval)timeInterval;
+ (long long)getPreYear0ClockTimeStamp:(NSTimeInterval)timeInterval;
+ (long long)getNextYear0ClockTimeStamp:(NSTimeInterval)timeInterval;

/**
 获得当天23:59:59点的时间戳
 
 @param timeInterval 当前时间时间戳
 @return 当天23:59:59点的时间戳
 */
+ (long long)getToday24ClockTimeStamp:(NSTimeInterval)timeInterval;

/// 向上取整到小时
- (NSDate *)ceilHour;

/// 向上取整到天
- (NSDate *)ceilDay;

/// 获取当月第一天和最后一天的日期字符串数组
- (NSArray *)getMonthFirstAndLastDayWithFormat:(NSString *)formatStr;

/// 获取当月第一天和最后一天的日期date数组
- (NSArray *)getMonthFirstAndLastDayDateArray;
@end
