//
//  LMLoadingImageView.h
//  SCCameraFramework
//
//  Created by MadHeart on 2017/12/1.
//  Copyright © 2017年   smart_camera. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LMLoadingImageView : UIImageView

@end
