//
//  LHCommonSecurityTool.h
//  SCCameraFramework
//
//  Created by MadHeart on 2019/6/1.
//  Copyright © 2019   smart_camera. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GMEllipticCurveCrypto.h"
#import "LMAppDefine.h"

NS_ASSUME_NONNULL_BEGIN

@interface LHCommonSecurityTool : NSObject
SINGLETON_HEADER(LHCommonSecurityTool);


/**
 通过ECC加密算法生成公私密钥

 @return GMEllipticCurveCrypto
 */
- (GMEllipticCurveCrypto *)getECCKeyPair;

/**
 通过交换公私钥生成SK


 @param remotePublicKey 远端公钥
 @param myPrivateKey 本地ECC私钥
 @return NSData
 */
- (NSData *)getShareKeyWithRemotePublicKey:(NSString *)remotePublicKey myPrivateKey:(NSString *)myPrivateKey;
- (NSData *)getShareKeyData:(NSData *)remoteData myPrivateKey:(NSString *)myPrivateKey;


/**
 通过HKDF秘钥派生函数 派生出对应数据

 @param sharedKey 共享密钥sharedKey
 @param salt NSData
 @param outputSize 输出NSData长度
 @return 目标NSData
 */
- (NSData *)getAES128KeyWihtShareKey:(NSData *)sharedKey salt:(NSData *)salt outputSize:(int)outputSize;

/**
 通过HKDF密钥派生函数 派生出蓝牙入网认证数据

 @param shareKey 共享密钥sharedKey
 @param salt NSData
 @param info 信息 NSData
 @param outputSize 输出NSData长度
 @return 目标数据
 */
- (NSData *)getBLEAuthValueByHKDFWithShareKey:(NSData *)shareKey salt:(NSData *)salt info:(NSData *)info outputSize:(int)outputSize;

- (void)getccmCryptWihtKey:(NSData *)key iv:(nullable NSData *)iv adata:(nullable NSData *)adata tagLength:(NSInteger)tagLength;

- (void)getAES_CCMDataWithKey:(NSData *)key iv:(nullable NSData *)iv adata:(nullable NSData *)adata message:(NSData *)message tagLength:(NSInteger)tagLength completion:(void(^)(NSData* data, NSError *error))completion;

/**
 AES_CCM 解密数据
 @param completion 结果
 */
- (void)getAES_CCMdecryptDataWithEncryptData:(NSData *)encryptdata completion:(nonnull void (^)(NSData *, NSError *))completion;

- (NSData *)getAES_CCMdecryptDataWithEncryptData:(NSData *)encryptdata;

- (NSData *)getCrcCode:(NSData *)data;
- (NSData *)getCrcData:(NSData *)data;
/**
 蓝牙配网CRC生成

 @param data Data
 @return NSData
 */
- (NSData *)getBLEAuthCRCCode:(NSData *)data;

/**
 蓝牙配网CRC32生成

 @param data 待加密数据
 @return NSData
 */
- (NSData *)getBLEAuthCRC32Code:(NSData *)data;
/**
 HMAC_SHA256 加密
 
 @param keyData 密钥
 @param data 待加密信息
 @return NSData
 */
- (NSData *)getHMac_SHA256HashWithKey:(NSData *)keyData data:(NSData *)data;

/// AES加密，密文内容用HEX编码
/// @param plainText 明文
/// @param key key
- (NSString *)encrypt:(NSString *)plainText key:(NSString *)key;

/// AES解密
/// @param encryptText 密文
/// @param key key
- (NSString *)decrypt:(NSString *)encryptText key:(NSString *)key;


/// AES加解密，密文内容用UTF8编码
/// @param plainText 密文
/// @param key key
- (NSString *)AES128EncryptUTF8:(NSString *)plainText key:(NSString *)key;
- (NSString *)AES128DecryptUTF8:(NSString *)encryptText key:(NSString *)key;


/// AES加解密，传Data数据
/// - Parameters:
///   - data: UTF8编码后的数据
///   - key: key
- (NSData *)AESEncryptData:(NSData *)data key:(NSString *)key;
- (NSData *)AESDecryptData:(NSData *)data key:(NSString *)key;
- (NSData *)AESDecryptData:(NSData *)data keyData:(NSData *)keyData;


/// AES 128 ECB加密
/// @param plainText 明文
/// @param key key
- (NSString *)AESECBEncrypt:(NSString *)plainText key:(NSString *)key;

/// AES 128 ECB解密
/// @param encryptText 密文
/// @param key key
- (NSString *)AESECBDecrypt:(NSString *)encryptText key:(NSString *)key;

/// AES256 CBC模式 加密
/// @param plainText 明文
/// @param key 密钥
/// @discussion 门锁使用
- (NSString *)AES256CBCEncrypt:(NSString *)plainText key:(NSString *)key;

/// AES256 CBC模式 解密
/// @param encryptText 密文
/// @param key 密钥
/// @discussion 门锁使用
- (NSString *)AES256CBCDecrypt:(NSString *)encryptText key:(NSString *)key;

- (NSString *)getHexByDecimal:(NSString *)decimalStr;
+ (NSString *)getHexByDecimal:(NSInteger)decimal;
- (NSData*)stringToData:(NSString*)inputVector;
+ (NSInteger)getDecimalByHexString:(NSString *)aHexString;

@end

NS_ASSUME_NONNULL_END
