//
//  LMLKP2PConnectParam.h
//  CameraP2PSDK
//
//  Created by chenshuang on 2021/11/11.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@class LMLKMHFrameEncryptPwdKey;

@interface LMLKP2PConnectParam : NSObject
/** 当前连接信息 */
@property(nonatomic, strong)NSString *connectString;
/** 设备 p2p id */
@property(nonatomic, strong)NSString *p2pID;
/** 加解密 */
@property(nonatomic, strong)LMLKMHFrameEncryptPwdKey *pwdKey;
/** subjectId */
@property(nonatomic, strong)NSString *subjectId;
/** 门锁用到的公钥 */
@property (nonatomic, copy) NSString *publicKey;

@end

NS_ASSUME_NONNULL_END
