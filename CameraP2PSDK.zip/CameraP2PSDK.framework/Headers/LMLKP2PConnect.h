//
//  LMLKP2PConnect.h
//  CameraP2PSDK
//
//  Created by chenshuang on 2021/11/11.
//

#import <Foundation/Foundation.h>
#import "LMLKP2PFunctionProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@interface LMLKP2PConnect : NSObject<LMLKP2PFunctionDelegate>

/// 初始化
/// @param param 建立连接的参数
/// @param type 类型
/// @param dataSource 数据回调接受者
- (instancetype)initWithParam:(LMLKP2PConnectParam *)param type:(LMLKP2PConnectType)type dataSource:(id<LMLKP2PFunctionDataSource>)dataSource;

@end

NS_ASSUME_NONNULL_END
