//
//  LMLKP2PHeader.h
//  SCCameraFramework
//
//  Created by chenshuang on 2019/12/30.
//  Copyright © 2019   smart_camera. All rights reserved.
//
/// P2P相关的枚举
#ifndef LMLKP2PHeader_h
#define LMLKP2PHeader_h

/// 消息类型，对应着通道
typedef NS_ENUM(UInt32, LMLK_P2PChannelType) {
    LMLK_P2PChannelType_CMD = 0,       // 命令
    LMLK_P2PChannelType_STREAM = 1,    // 视频流 + 音频流
    LMLK_P2PChannelType_TALK = 2,      // 通话
    LMLK_P2PChannelType_REC_IDX = 3,   // 回放历史 - 时间轴
    /// 门锁用到的通道类型
    LMLK_P2PChannelType_Lock_CMD = LMLK_P2PChannelType_CMD,        ///命令
    LMLK_P2PChannelType_Lock_VIDEO = LMLK_P2PChannelType_STREAM,   ///视频流
    LMLK_P2PChannelType_Lock_AUDIO = LMLK_P2PChannelType_TALK,     ///音频流
};

/// p2p错误码
typedef NS_ENUM(NSInteger, LMLKP2PCamManagerErrorCode) {
    LHCAM_ERROR_PPCS_SUCCESSFUL                             = 0,    ///p2p成功
    LHCAM_ERROR_PPCS_NOT_INITIALIZED                        = -1,   ///p2p没有初始化
    LHCAM_ERROR_PPCS_ALREADY_INITIALIZED                    = -2,   ///p2p已经初始化
    LHCAM_ERROR_PPCS_TIME_OUT                               = -3,   ///p2p超时
    LHCAM_ERROR_PPCS_INVALID_ID                             = -4,   ///p2p无效ID
    LHCAM_ERROR_PPCS_INVALID_PARAMETER                      = -5,   ///p2p无效参数
    LHCAM_ERROR_PPCS_DEVICE_NOT_ONLINE                      = -6,   ///设备不在线
    LHCAM_ERROR_PPCS_FAIL_TO_RESOLVE_NAME                   = -7,   ///解析名字失败
    LHCAM_ERROR_PPCS_INVALID_PREFIX                         = -8,   ///无效的前缀
    LHCAM_ERROR_PPCS_ID_OUT_OF_DATE                         = -9,   ///设备ID已过期
    LHCAM_ERROR_PPCS_NO_RELAY_SERVER_AVAILABLE              = -10,  ///没有可以依赖的服务器
    LHCAM_ERROR_PPCS_INVALID_SESSION_HANDLE                 = -11,  ///无效的session句柄
    LHCAM_ERROR_PPCS_SESSION_CLOSED_REMOTE                  = -12,  ///远程session关闭
    LHCAM_ERROR_PPCS_SESSION_CLOSED_TIMEOUT                 = -13,  ///远程session调用关闭
    LHCAM_ERROR_PPCS_SESSION_CLOSED_CALLED                  = -14,  ///远程session调用关闭
    LHCAM_ERROR_PPCS_REMOTE_SITE_BUFFER_FULL                = -15,  ///远程buffer满
    LHCAM_ERROR_PPCS_USER_LISTEN_BREAK                      = -16,  ///用户监听中断
    LHCAM_ERROR_PPCS_MAX_SESSION                            = -17,  ///已经达到最大session数
    LHCAM_ERROR_PPCS_UDP_PORT_BIND_FAILED                   = -18,  ///UDP端口绑定失败
    LHCAM_ERROR_PPCS_USER_CONNECT_BREAK                     = -19,  ///用户连接中断
    LHCAM_ERROR_PPCS_SESSION_CLOSED_INSUFFICIENT_MEMORY     = -20,  ///session关闭，没有足够的内存
    LHCAM_ERROR_PPCS_INVALID_APILICENSE                     = -21,  ///无效API证书
    LHCAM_ERROR_PPCS_FAIL_TO_CREATE_THREAD                  = -22,  ///p2p创建线程失败
    LHCAM_ERROR_PPCS_INITIALIZED_FAILED                     = -1000,///p2p初始化失败
    LHCAM_ERROR_PPCS_CONNECT_FAILED                         = -1001,///P2P连接失败
    LHCAM_ERROR_PPCS_DEVICE_SLEEP                           = -1002,///设备休眠
    LHCAM_ERROR_PPCS_NOT_CONNECT                            = -1003,///P2P未连接
};

/// p2p连接状态
typedef NS_ENUM(NSInteger, LMLK_P2PCamManagerConnectStatus) {
    LMLK_P2PCamManagerConnectStatus_WillConnect                = -2,   ///将要连接
    LMLK_P2PCamManagerConnectStatus_Connecting                 = -1,   ///连接中
    LMLK_P2PCamManagerConnectStatus_DidConnect                 = 0,    ///已连接
    LMLK_P2PCamManagerConnectStatus_DisConnecting              = 1,    ///断开连接中
    LMLK_P2PCamManagerConnectStatus_DisConnected               = 2,    ///断开连接
};

/// p2p解析错误
typedef NS_ENUM(NSInteger, LMLKP2PDataManagerErrorType) {
    LMLKP2PDataManagerErrorType_AudioDecoderError             = -2000, ///音频解密失败
    LMLKP2PDataManagerErrorType_VideoDecoderError             = -2001, ///视频解密失败
    LMLKP2PDataManagerErrorType_AudioLegalAACDecoderError     = -2002, ///AAC头部不是0xff
};

/// p2p建立连接过程发生失败
typedef NS_ENUM(NSInteger, LMLK_P2PBuildConnectErrorType) {
    LMLK_P2PBuildConnectErrorType_InitializeError = -101,          // PPCS_Initialize (ret = -3)
    LMLK_P2PBuildConnectErrorType_NotInitialized = -102,           // PPCS_Connect (ret == -1)
    LMLK_P2PBuildConnectErrorType_ConnectError = -103,             // PPCS_Connect (ret < 0 && ret != -1)
    LMLK_P2PBuildConnectErrorType_CheckSessionIDError = -104,      // PPCS_Check
};

/// p2p错误回调信息类型
typedef NS_ENUM(NSInteger, LMLK_P2PConnectErrorType) {
    LMLK_P2PConnectErrorType_InvalidParameter = -201,          // invalid parameter(addressStr 与 p2pIdStr is invalid)
    LMLK_P2PConnectErrorType_InitializeError = -202,           // PPCS_Initialize (ret < 0 && ret != -2 && ret != -3)
    LMLK_P2PConnectErrorType_CheckBuffer = -203,               // PPCS_Check_Buffer(ret < 0)
    LMLK_P2PConnectErrorType_AudioDecoderError = -204,         // 音频解密失败
    LMLK_P2PConnectErrorType_VideoDecoderError = -205,         // 视频解密失败
    LMLK_P2PConnectErrorType_AudioLegalAACDecoderError = -206, // AAC头部不是0xff
    LMLK_P2PConnectErrorType_PPCSRead = -207,               // PPCS_Read(ret < 0)
};

// 直播码流
typedef enum : NSUInteger {
    LMLKCameraVideoStreamFullHD = 0,
    LMLKCameraVideoStreamHD = 1,
    LMLKCameraVideoStreamSD = 2
} LMLKCameraVideoStream;

// 回放速率
typedef enum : NSUInteger {
    LMLKCameraPlaybackSpeed1  = 0,
    LMLKCameraPlaybackSpeed2,
    LMLKCameraPlaybackSpeed4,
//    LMLKCameraPlaybackSpeed16,
} LMLKCameraPlaybackSpeed;

#endif /* LMLKP2PHeader_h */
