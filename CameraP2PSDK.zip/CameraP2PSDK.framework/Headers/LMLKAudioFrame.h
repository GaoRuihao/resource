//
//  LMLKAudioFrame.h
//  Lumi
//
//  Created by PandaLZMing on 2018/7/5.
//

#import <Foundation/Foundation.h>

@class LMLKAudioFrameHeader;

@interface LMLKAudioFrame : NSObject

/// 音频桢类型
@property (nonatomic, assign) NSInteger frameType;
@property (nonatomic, strong) LMLKAudioFrameHeader *audioHeader;
@property (nonatomic, strong) NSData *frameInfo;
@property (nonatomic, strong) NSData *audioBuffer;
@property (nonatomic, strong) NSData* rawAudioData;
@property (nonatomic, assign) int codec;
/** 音频时间戳 毫秒 */
@property(nonatomic, assign)long long audioTimeStamp;
//@property (nonatomic, assign) int flags;

@end

