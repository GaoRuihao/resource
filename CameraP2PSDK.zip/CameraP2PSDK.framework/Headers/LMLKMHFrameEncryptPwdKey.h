//
//  LMLKMHFrameEncryptPwdKey.h
//  MiHome
//
//  Created by hanyunhui on 2017/10/30.
//  Copyright © 2017年 小米移动软件. All rights reserved.
//  米家摄像机加密的key

#import <Foundation/Foundation.h>
#define LMLKPwdKeyLength 32

@interface LMLKMHFrameEncryptPwdKey : NSObject

@property (nonatomic, copy) NSString* account;
@property (nonatomic, copy) NSString* pwd;
@property (nonatomic, copy) NSString* remoteSing;
@property (nonatomic, copy) NSString* remoteKey;    //设备公钥
@property (nonatomic, strong) NSString *timeStr;
@property (nonatomic) unsigned char* privateKey;     //APP的秘钥
@property (nonatomic) unsigned char* publicKey;     //APP的公钥
@property (nonatomic) unsigned char* shareKey;
@end
