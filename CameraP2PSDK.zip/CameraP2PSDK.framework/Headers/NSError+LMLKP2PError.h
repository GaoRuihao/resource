//
//  NSError+LMLKP2PError.h
//  SCCameraFramework
//
//  Created by Charles on 2019/10/29.
//  Copyright © 2019   smart_camera. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSError (LMLKP2PError)

/// 错误码转NSError
/// @param errorCode 错误码
+ (NSError *)errorWithCode:(NSInteger)errorCode;

@end

NS_ASSUME_NONNULL_END
