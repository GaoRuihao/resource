//
//  LMByteConverter.h
//  SCCameraFramework
//
//  Created by Charles on 2019/11/4.
//  Copyright © 2019   smart_camera. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LMByteConverter : NSObject

#pragma mark - Value To Bytes
/// int8_t转Byte
/// @param value int8_t value
+ (const void *)byteFromInt8:(int8_t)value;

/// UInt8转Byte
/// @param value UInt8 value
+ (const void *)byteFromUInt8:(UInt8)value;

/// UInt16转Byte
/// @param value UInt16 value
+ (const void *)byteFromUInt16:(UInt16)value;

/// UInt24转Byte
/// @param value UInt32 value
+ (const void *)byteFromUInt24:(UInt32)value;

    
/// UInt32转Byte
/// @param value UInt32 value
+ (const void *)byteFromUInt32:(UInt32)value;

/// UInt64转Byte
/// @param value UInt64 value
+ (const void *)byteFromUInt64:(UInt64)value;

/// Short转Byte
/// @param value Short value
+ (const void *)byteFromShort:(short)value;

/// Bool转Byte
/// @param value Bool value
+ (const void *)byteFromBool:(BOOL)value;

/// String转NSData
/// @param value NSString value
+ (NSData *)byteFromString:(NSString *)value;

/// /// String转NSData(不加结束符)
/// @param value NSString value
+ (NSData *)byteFromString2:(NSString *)value;

/// HexString转NSData
/// @param value NSString hex
+ (NSData *)byteHexString:(NSString *)value;

#pragma mark - Btyes to Value
/// Byte转int8_t
/// @param bytes bytes
+ (int8_t)int8FromByte:(const char *)bytes;

/// Byte转UInt8
/// @param bytes bytes
+ (UInt8)UInt8FromByte:(const char *)bytes;

/// Byte转UInt16
/// @param bytes bytes
+ (UInt16)UInt16FromByte:(const char *)bytes;

/// Byte转UInt32
/// @param bytes bytes
+ (UInt32)UInt32FromByte:(const char *)bytes;

/// Byte转UInt64
/// @param bytes bytes
+ (UInt64)UInt64FromByte:(const char *)bytes;

/// Byte转Short
/// @param bytes bytes
+ (short)shortFrombyte:(const char *)bytes;

/// Byte转BOOL
/// @param bytes bytes
+ (BOOL)BoolFrombyte:(const char *)bytes;

/// Byte转NSData
/// @param bytes bytes
/// @param length bytes length
+ (NSData *)dateFromByte:(const void *)bytes withLength:(NSInteger)length;

/// Byte转NSString
/// @param bytes bytes
/// @param length bytes length
+ (NSString *)stringFromByte:(const void *)bytes withLength:(NSInteger)length;

/// Byte转NSString(不去除结束符)
/// @param bytes bytes
/// @param length length
+ (NSString *)stringFromByte2:(const void *)bytes withLength:(NSInteger)length;

/// NSData转NSString
/// @param data NSData
//+ (NSString *)stringFromData:(NSData*)data;

/// Byte转HexString
/// @param bytes bytes
/// @param length bytes length
+ (NSString *)hexStringFromeByte:(const void *)bytes withLength:(NSInteger)length;

//data转换为十六进制数据字符串
+ (NSString *)byteToHexString:(NSData *)data;

/// data转ascii字符串
+ (NSString *)dataToAsciiString:(NSData *)data;

@end

NS_ASSUME_NONNULL_END
