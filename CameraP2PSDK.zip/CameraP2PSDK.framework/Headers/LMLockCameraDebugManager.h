//
//  LMLockCameraDebugManager.h
//  SCCameraFramework
//
//  Created by Charles on 2019/12/26.
//  Copyright © 2019   smart_camera. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LMLockCameraDebugManager : NSObject

/// 当前时间戳
@property (nonatomic, copy) NSString *C_TS;

/// 音视频总接收大小
@property (nonatomic, assign) NSInteger PRS_T;

/// cmd接收总大小
@property (nonatomic, assign) NSInteger PRS_C;

/// 视频接收总大小
@property (nonatomic, assign) NSInteger PRS_V;

/// 音频接收总大小
@property (nonatomic, assign) NSInteger PRS_A;

/// 每秒接收的总码率
@property (nonatomic, assign) NSInteger KBPS;

/// 每秒接收的视频码率
@property (nonatomic, assign) NSInteger KBPS_V;

/// 每秒接收的音频码率
@property (nonatomic, assign) NSInteger KBPS_A;

/// 视频分辨率
@property (nonatomic, copy) NSString *DPI;

/// 视频默认帧率
@property (nonatomic, assign) NSInteger FPS_D;

/// 视频播放帧率
@property (nonatomic, assign) NSInteger FPS;

/// 音频默认帧率
@property (nonatomic, assign) NSInteger FPS_AD;

/// 音频播放帧率
@property (nonatomic, assign) NSInteger FPS_A;

/// 视频格式
@property (nonatomic, copy) NSString *F_V;

/// 音频格式
@property (nonatomic, copy) NSString *F_A;

/// 视频渲染次数
@property (nonatomic, assign) NSInteger PC_V;

/// 音频渲染次数
@property (nonatomic, assign) NSInteger PC_A;

/// 视频接收的帧序号
@property (nonatomic, assign) NSInteger RN_V;

/// 音频接收的帧序号
@property (nonatomic, assign) NSInteger RN_A;

/// 视频播放的帧序号
@property (nonatomic, assign) NSInteger PN_V;

/// 音频播放的帧序号
@property (nonatomic, assign) NSInteger PN_A;

/// 视频丢包率
@property (nonatomic, assign) float PLR_V;

/// 音频丢包率
@property (nonatomic, assign) float PLR_A;

/// 视频缓存帧数
@property (nonatomic, assign) NSInteger CN_V;

/// 音频缓存帧数
@property (nonatomic, assign) NSInteger CN_A;

/// 缓存区第一帧视频的时间戳
@property (nonatomic, assign) NSInteger CMT_V;

/// 缓存区第一帧音频的时间戳(对于iOS来说，实际上是播放器内缓存的第一帧的时间戳)
@property (nonatomic, assign) NSInteger CMT_A;

/// 当前接收到的最新视频帧的时间戳
@property (nonatomic, assign) NSInteger RMT_V;

/// 当前接收到的最新音频帧的时间戳
@property (nonatomic, assign) NSInteger RMT_A;

/// 当前播放视频帧的时间戳
@property (nonatomic, assign) NSInteger CT_V;

/// 当前播放音频帧的时间戳
@property (nonatomic, assign) NSInteger CT_A;

/// 单例
+ (instancetype)sharedInstance;

/// 开始监控
- (void)startMonitor;

/// 停止监控
- (void)stopMonitor;

/// 更新总数据接收大小
- (void)updateTotleReceiveSize:(NSUInteger)totleReceiveSize;

/// 更新CMD数据接收大小
- (void)updateCmdReceiveSize:(NSUInteger)cmdReceiveSize;

/// 更新视频数据接收大小
- (void)updateVideoReceiveSize:(NSUInteger)videoReceiveSize;

/// 更新音频数据接收大小
- (void)updateAudioReceiveSize:(NSUInteger)audioReceiveSize;

/// 更新视频渲染帧数
- (void)updateVideoPlayCount;

/// 更新音频渲染帧数
- (void)updateAudioPlayCount;

/// 打开音频
- (void)statrAudio;

/// 关闭音频
- (void)stopAudio;

/// 打开视频
- (void)startVideo;

/// 关闭视频
- (void)stopVideo;

/// 打开通话
- (void)startTalk;

/// 关闭通话
- (void)stopTalk;

/// 写log
/// @param logString log内容
- (void)writeLogString:(NSString *)logString;

/// 写模块日志
/// @param logString 日志内容
- (void)writeModuleLogString:(NSString *)logString;

/// 写音视频参数日志
/// @param logString 日志内容
- (void)writeVAParamLogString:(NSString *)logString;

/// 写状态参数日志
/// @param logString 日志内容
- (void)wirteStateParamLogString:(NSString *)logString;

@end

NS_ASSUME_NONNULL_END
