//
//  LMLKConstant.h
//  commonDemo
//
//  Created by dengzhihao on 2017/11/20.
//  Copyright © 2017年 LM21Mac002. All rights reserved.
//
#import <Foundation/Foundation.h>

#ifndef LMLKConstant_h
#define LMLKConstant_h

FOUNDATION_EXTERN NSString * const kLH_P2PErrorDomain;
FOUNDATION_EXTERN NSString * const kSCLKP2PCodecTypeAACKey;
FOUNDATION_EXTERN NSString * const kSCCAP2PCodecTypeG711AKey;
FOUNDATION_EXTERN NSString * const kSCCAP2PMonoChannelKey;
FOUNDATION_EXTERN NSString * const kSCCAP2PStereoChannelKey;

#endif /* LMLKConstant_h */

//FOUNDATION_EXTERN NSString * const

//NSString *const

//const CGFloat
