//
//  SCCameraManager.h
//  SCCameraFramework
//
//  Created by 高瑞浩 on 2024/10/4.
//  Copyright © 2024 smart_camera. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SCCameraDefine.h"

NS_ASSUME_NONNULL_BEGIN

typedef enum {
    SCCameraSignalFront,    ///前置摄像头
    SCCameraSignalRear      ///后置摄像头
}SCCameraSignal;

// 直播码流
typedef enum : NSUInteger {
    SCameraVideoStreamFullHD = 0,
    SCameraVideoStreamHD = 1,
    SCameraVideoStreamSD = 2
} SCameraVideoStream;

typedef enum : NSUInteger {
    /// 无错误
    SCameraConnectStatusNoError = 0,
    /// 设备离线
    SCameraConnectStatusDeviceNotOnLine = 1,
    /// 密码错误
    SCameraConnectStatusPasswordError = 2,
    /// 视频流中断（P2P异常的状态）
    SCameraConnectStatusVideoOff = 3,
    /// 超时
    SCameraConnectStatusTimeout = 4,
    /// 无网络
    SCameraConnectStatusNoNetWork = 5,
    /// 其他错误
    SCameraConnectStatusOtherError = 6,
} SCameraConnectStatus;

// 回放码流
typedef enum : NSUInteger {
    SCameraPlaybackVideoStreamFullHD = 0,    // 超清
    SCameraPlaybackVideoStreamSD = 1 // 标清-自动
} SCameraPlaybackVideoStream;

@interface SCCameraManager : NSObject

@property(nonatomic, strong)NSString *did;

@property(nonatomic)SCConnectorMode connectMode;
/// 获取播放进度
@property(nonatomic)CGFloat playbackProgress;

- (instancetype)initWithDid:(NSString *)did;

//- (UIView *)getCameraPlayerView;

- (UIView *)getCameraPlayerViewWithFrame:(CGRect)frame;

- (void)startPlayLiveWithType:(SCCameraSignal)signal;

- (void)resumePlayLive;

- (void)stopPlayLive;

- (void)toggleSignal;

- (void)playBackVideoWithTime:(long)time pathName:(NSString *)pathName fileName:(NSString *)fileName duration:(long)duration;

//- (void)setupConnect;

/// change video ratio
- (void)changeLiveResolutionRatio:(SCameraVideoStream)ratio;

/// voice mute
- (void)setMute:(BOOL)isMute;

/// method for current video stream speed
/// - Parameter speedBlock: return the speed size for kb/s
- (void)addObserverForSpeed:(void(^)(NSString *size))speedBlock;

/// method for P2P connect status callback
- (void)addObserverForConnectStatus:(void(^)(SCameraConnectStatus connectStatus))connectStatusBlock;

@end

NS_ASSUME_NONNULL_END
